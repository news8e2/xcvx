<?php return array('dependencies' => array('react', 'wp-hooks'), 'version' => 'c573607fd1beec181120');
