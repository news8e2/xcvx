<?php
/**
 * Plugin Name: Persian
 * Description: Persian
 * Plugin URI:  https://abzarwp.com/
 * Author:      Abzarwp Group
 * Author URI:  https://abzarwp.com
 * Version:     2.0.4
 * Text Domain: abzarwp-persian-jet-library
 * Domain Path: /languages
 * Requires at least: 5.0.0
 * Requires PHP: 7.4
 */
